import React, { useState } from 'react';
import { 
  X, Check, Sparkles, Building2, Star, ShieldCheck, 
  Cloud, Bot, Megaphone, ArrowRight, Store, ShoppingBag, 
  Clock, MapPin, Plus, Trash2, Edit3, MessageCircle, 
  Smartphone, Send, RefreshCw, AlertCircle, Award, CreditCard
} from 'lucide-react';
import { User, UserPlanType, BusinessProfile, BusinessProduct, StorageBreakdown, SponsoredAd } from '../types';
import { MONETIZATION_PLANS, DEFAULT_BUSINESS_CATALOG, DEFAULT_STORAGE_QUOTA, INITIAL_SPONSORED_ADS } from '../data/monetizationData';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onUpdateUser: (updated: Partial<User>) => void;
  onOpenDirectChat?: (userId: string) => void;
  initialTab?: 'plans' | 'business' | 'ai' | 'ads' | 'verification' | 'storage';
  onOpenBackupRestore?: (tab?: 'export' | 'restore' | 'drive') => void;
}

export const BusinessAndPlansModal: React.FC<Props> = ({
  isOpen,
  onClose,
  currentUser,
  onUpdateUser,
  onOpenDirectChat,
  onOpenBackupRestore,
  initialTab = 'plans'
}) => {
  const [activeTab, setActiveTab] = useState<'plans' | 'business' | 'ai' | 'ads' | 'verification' | 'storage'>(initialTab);

  // Business state
  const currentPlan = currentUser.plan || 'free';
  const [businessProfile, setBusinessProfile] = useState<BusinessProfile>(() => {
    if (currentUser.businessProfile) return currentUser.businessProfile;
    return {
      isBusiness: currentPlan === 'business',
      businessName: currentUser.name || 'Mi Negocio Nica',
      category: 'Comidería & Gastronomía',
      hours: 'Lunes a Sábado: 8:00 AM – 6:00 PM',
      department: 'Managua',
      address: 'De la rotonda El Güegüense 2c abajo, Managua',
      whatsapp: currentUser.phone || '+505 8888 9999',
      website: 'https://naulchat.ni',
      catalog: DEFAULT_BUSINESS_CATALOG,
      aiBotEnabled: true,
      aiBotWelcomeMessage: '¡Hola! Bienvenido a nuestro negocio en Naul Chat. ¿En qué podemos servirle hoy? Pregunte por nuestro menú y entregas.',
      aiBotPrompt: 'Eres el asistente virtual amable de un comercio nicaragüense. Responde precios en Córdobas (C$), horarios y formas de pago (LAFISE, BAC, Efectivo).',
      aiBotFaq: [
        { question: '¿Cuál es el horario de atención?', answer: 'Atendemos de Lunes a Sábado de 8:00 AM a 6:00 PM.' },
        { question: '¿Hacen envíos a domicilio?', answer: 'Sí, hacemos entregas rápidas en la ciudad y por CargoTrans / EnviaYa a departamentos.' },
        { question: '¿Qué formas de pago aceptan?', answer: 'Aceptamos transferencias LAFISE Bancentro, BAC Credomatic, Billetera Móvil Banpro y efectivo contra entrega.' }
      ]
    };
  });

  // Storage state
  const storageQuota: StorageBreakdown = currentUser.storageQuota || DEFAULT_STORAGE_QUOTA[currentPlan];

  // Plan activation feedback
  const [activatedSuccessMessage, setActivatedSuccessMessage] = useState<string | null>(null);

  // New product form in catalog
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [newProductTitle, setNewProductTitle] = useState('');
  const [newProductPrice, setNewProductPrice] = useState(150);
  const [newProductDesc, setNewProductDesc] = useState('');
  const [newProductCategory, setNewProductCategory] = useState('Especial');

  // AI Interactive Simulator
  const [testUserMessage, setTestUserMessage] = useState('');
  const [simulatedChatHistory, setSimulatedChatHistory] = useState<Array<{ sender: 'user' | 'bot'; text: string; time: string }>>([
    {
      sender: 'bot',
      text: businessProfile.aiBotWelcomeMessage || '¡Hola! Bienvenido a nuestro perfil comercial. ¿En qué podemos atenderle hoy?',
      time: 'Ahora'
    }
  ]);

  // Verification request form state
  const [verificationType, setVerificationType] = useState<'cedula' | 'ruc' | 'business'>('cedula');
  const [verificationDocNumber, setVerificationDocNumber] = useState('');
  const [verificationSuccess, setVerificationSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSelectPlan = (planId: 'free' | 'premium_basic' | 'premium_pro' | 'business_starter' | 'business_pro') => {
    let newPlan: UserPlanType = 'free';
    let newBadge: User['badgeType'] = undefined;
    let quota = DEFAULT_STORAGE_QUOTA.free;

    if (planId === 'premium_basic' || planId === 'premium_pro') {
      newPlan = 'premium';
      newBadge = 'star_premium';
      quota = DEFAULT_STORAGE_QUOTA.premium;
    } else if (planId === 'business_starter' || planId === 'business_pro') {
      newPlan = 'business';
      newBadge = 'business_verified';
      quota = DEFAULT_STORAGE_QUOTA.business;
    }

    const updatedUser: Partial<User> = {
      plan: newPlan,
      badgeType: newBadge,
      isVerified: newPlan !== 'free',
      storageQuota: quota,
      businessProfile: {
        ...businessProfile,
        isBusiness: newPlan === 'business'
      }
    };

    onUpdateUser(updatedUser);
    setActivatedSuccessMessage(`¡Plan actualizado con éxito a ${newPlan === 'free' ? 'Gratis' : newPlan === 'premium' ? 'Naul Premium ⭐' : 'Perfil Comercial 🏪'}!`);
    setTimeout(() => setActivatedSuccessMessage(null), 4000);
  };

  const handleSaveBusinessProfile = () => {
    const updatedUser: Partial<User> = {
      businessProfile: {
        ...businessProfile,
        isBusiness: true
      },
      plan: 'business',
      badgeType: 'business_verified',
      isVerified: true
    };
    onUpdateUser(updatedUser);
    setActivatedSuccessMessage('¡Perfil comercial guardado y sincronizado con éxito! 🏪✅');
    setTimeout(() => setActivatedSuccessMessage(null), 3500);
  };

  const handleAddProductToCatalog = () => {
    if (!newProductTitle.trim()) return;
    const newProd: BusinessProduct = {
      id: `prod-${Date.now()}`,
      title: newProductTitle.trim(),
      priceCordobas: Number(newProductPrice) || 100,
      description: newProductDesc.trim() || 'Producto disponible para compra y entrega inmediata.',
      imageUrl: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=400&auto=format&fit=crop&q=80',
      category: newProductCategory,
      inStock: true
    };
    const updatedCatalog = [newProd, ...businessProfile.catalog];
    const updatedProfile = { ...businessProfile, catalog: updatedCatalog };
    setBusinessProfile(updatedProfile);
    onUpdateUser({ businessProfile: updatedProfile });
    setNewProductTitle('');
    setNewProductDesc('');
    setShowAddProduct(false);
  };

  const handleRemoveProduct = (prodId: string) => {
    const updatedCatalog = businessProfile.catalog.filter(p => p.id !== prodId);
    const updatedProfile = { ...businessProfile, catalog: updatedCatalog };
    setBusinessProfile(updatedProfile);
    onUpdateUser({ businessProfile: updatedProfile });
  };

  const handleSimulateAiResponse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testUserMessage.trim()) return;
    const userText = testUserMessage.trim();
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    // Add user message
    setSimulatedChatHistory(prev => [...prev, { sender: 'user', text: userText, time: now }]);
    setTestUserMessage('');

    // Generate intelligent business answer based on prompt and catalog
    setTimeout(() => {
      let botReply = '';
      const lower = userText.toLowerCase();

      if (lower.includes('precio') || lower.includes('cuanto') || lower.includes('vale') || lower.includes('costo')) {
        const item = businessProfile.catalog[0];
        botReply = `¡Con gusto! Nuestro "${item?.title || 'producto'}" tiene un precio de C$${item?.priceCordobas || 180} Córdobas. ¿Desea que tomemos su orden para entrega?`;
      } else if (lower.includes('horario') || lower.includes('abierto') || lower.includes('hora')) {
        botReply = `Nuestro horario de atención es: ${businessProfile.hours}. ¡Estamos para servirle!`;
      } else if (lower.includes('donde') || lower.includes('ubicacion') || lower.includes('direccion')) {
        botReply = `Nos encontramos en: ${businessProfile.address}, departamento de ${businessProfile.department}, Nicaragua.`;
      } else if (lower.includes('envio') || lower.includes('delivery') || lower.includes('entrega')) {
        botReply = '¡Sí hacemos entregas a domicilio! En Managua y alrededores mediante mensajería directa, y a otros departamentos por CargoTrans o EnviaYa.';
      } else if (lower.includes('pago') || lower.includes('tarjeta') || lower.includes('transferencia')) {
        botReply = 'Aceptamos transferencias a cuentas LAFISE Bancentro, BAC Credomatic, Billetera Móvil Banpro y efectivo en Córdobas (C$) o Dólares.';
      } else {
        botReply = `¡Gracias por comunicarse con ${businessProfile.businessName}! Con gusto le atendemos de inmediato. ¿Desea consultar nuestro catálogo de productos o hacer un pedido?`;
      }

      setSimulatedChatHistory(prev => [
        ...prev, 
        { sender: 'bot', text: botReply, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }
      ]);
    }, 600);
  };

  const handleRequestVerification = (e: React.FormEvent) => {
    e.preventDefault();
    if (!verificationDocNumber.trim()) return;
    
    onUpdateUser({
      isVerified: true,
      verificationStatus: 'verified',
      badgeType: verificationType === 'business' || verificationType === 'ruc' ? 'business_verified' : 'citizen_verified'
    });
    setVerificationSuccess(true);
    setActivatedSuccessMessage('¡Solicitud aprobada! Insignia oficial asignada a tu perfil.');
    setTimeout(() => {
      setActivatedSuccessMessage(null);
    }, 4000);
  };

  // Storage percentage calculation
  const storagePercent = Math.min(100, Math.round((storageQuota.usedMb / storageQuota.totalMb) * 100));

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-[#091322] border border-slate-700/80 w-full max-w-4xl max-h-[92vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden text-white">
        
        {/* Modal Top Header */}
        <div className="px-5 py-4 border-b border-slate-800 bg-[#070e1a] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-sky-500/20">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold font-display text-white">
                  Naul Chat Nicaragua: Planes, Negocios & Monetización
                </h2>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  En Córdobas (C$)
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Cómo funcionaría el ecosistema: usuarios gratis, comercios locales, IA 24/7 y funciones VIP
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            title="Cerrar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Global Toast Notification */}
        {activatedSuccessMessage && (
          <div className="bg-emerald-500/15 border-b border-emerald-500/30 px-5 py-2.5 flex items-center gap-2 text-xs font-semibold text-emerald-300 animate-in slide-in-from-top-2">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{activatedSuccessMessage}</span>
          </div>
        )}

        {/* Main Navigation Tabs */}
        <div className="bg-[#050b14] border-b border-slate-800/80 px-4 flex items-center gap-1 overflow-x-auto scrollbar-none text-xs font-medium">
          <button
            onClick={() => setActiveTab('plans')}
            className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeTab === 'plans' 
                ? 'border-sky-400 text-sky-400 font-bold bg-sky-500/5' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Star className="w-4 h-4 text-amber-400" />
            <span>Planes & Precios (C$)</span>
          </button>

          <button
            onClick={() => setActiveTab('business')}
            className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeTab === 'business' 
                ? 'border-sky-400 text-sky-400 font-bold bg-sky-500/5' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Store className="w-4 h-4 text-emerald-400" />
            <span>🏪 Perfil Comercial & Catálogo</span>
          </button>

          <button
            onClick={() => setActiveTab('ai')}
            className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeTab === 'ai' 
                ? 'border-sky-400 text-sky-400 font-bold bg-sky-500/5' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bot className="w-4 h-4 text-sky-400" />
            <span>🤖 IA para Negocios (24/7)</span>
          </button>

          <button
            onClick={() => setActiveTab('ads')}
            className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeTab === 'ads' 
                ? 'border-sky-400 text-sky-400 font-bold bg-sky-500/5' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Megaphone className="w-4 h-4 text-rose-400" />
            <span>📢 Anuncios en Estados</span>
          </button>

          <button
            onClick={() => setActiveTab('verification')}
            className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeTab === 'verification' 
                ? 'border-sky-400 text-sky-400 font-bold bg-sky-500/5' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-blue-400" />
            <span>✅ Verificación Oficial</span>
          </button>

          <button
            onClick={() => setActiveTab('storage')}
            className={`py-3 px-3.5 border-b-2 flex items-center gap-2 transition cursor-pointer shrink-0 ${
              activeTab === 'storage' 
                ? 'border-sky-400 text-sky-400 font-bold bg-sky-500/5' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cloud className="w-4 h-4 text-cyan-400" />
            <span>☁️ Almacenamiento Nube</span>
          </button>
        </div>

        {/* Tab Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#070e1a]/50 space-y-6">

          {/* TAB 1: PLANES & PRECIOS (CÓMO FUNCIONARÍA) */}
          {activeTab === 'plans' && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-sky-950/60 via-slate-900 to-indigo-950/60 border border-sky-500/20 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-sky-400">
                    Ecosistema y Monetización Sostenible
                  </span>
                  <h3 className="text-lg font-bold text-white mt-0.5">
                    ¿Cómo funcionaría Naul Chat Nicaragua?
                  </h3>
                  <p className="text-xs text-slate-300 mt-1 max-w-xl leading-relaxed">
                    Un modelo diseñado para la economía nicaragüense: gratis para que toda la población hable y comparta sin costo, y con planes accesibles en Córdobas (C$) para emprendedores, negocios locales y usuarios que deseen funciones prémium y almacenamiento ilimitado.
                  </p>
                </div>

                <div className="bg-slate-900/90 border border-slate-700/80 rounded-xl p-3 shrink-0 text-center sm:text-right">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold">Tu Estado Actual</span>
                  <div className="text-sm font-bold text-sky-300 flex items-center justify-center sm:justify-end gap-1.5 mt-0.5">
                    {currentPlan === 'free' && <span>🆓 Usuario Gratis</span>}
                    {currentPlan === 'premium' && <span>⭐ Usuario Premium</span>}
                    {currentPlan === 'business' && <span>🏪 Comercio Verificado</span>}
                  </div>
                </div>
              </div>

              {/* Grid of Plans */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* 1. USUARIOS GRATIS */}
                <div className="bg-[#0b1424] border border-slate-800 rounded-2xl p-5 flex flex-col justify-between hover:border-slate-700 transition">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                        🆓 Usuarios
                      </span>
                      <span className="text-xs text-emerald-400 font-semibold">100% Gratis</span>
                    </div>

                    <div>
                      <div className="flex items-baseline gap-1">
                        <span className="text-3xl font-extrabold text-white">C$0</span>
                        <span className="text-xs text-slate-400">/ mes</span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">
                        Chat, llamadas de voz y video, fotos y estados gratis sin suscripción.
                      </p>
                    </div>

                    <div className="border-t border-slate-800/80 pt-3 space-y-2 text-xs text-slate-300">
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>Chat cifrado E2EE ilimitado</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>Llamadas y videollamadas gratis</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>Envío de fotos y notas de voz</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>Publicación de Estados 24h</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>1 GB de almacenamiento en nube</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-5">
                    <button
                      onClick={() => handleSelectPlan('free')}
                      className={`w-full py-2.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
                        currentPlan === 'free'
                          ? 'bg-slate-800 text-slate-400 cursor-default'
                          : 'bg-slate-800 hover:bg-slate-700 text-white'
                      }`}
                    >
                      {currentPlan === 'free' ? '✓ Plan Activo' : 'Elegir Plan Gratis'}
                    </button>
                  </div>
                </div>

                {/* 2. PREMIUM USUARIOS */}
                <div className="bg-gradient-to-b from-[#141b2c] to-[#0c1424] border-2 border-amber-500/40 rounded-2xl p-5 flex flex-col justify-between shadow-xl shadow-amber-500/5 relative">
                  <div className="absolute -top-3 right-4 px-2.5 py-0.5 rounded-full bg-amber-500 text-slate-950 text-[10px] font-extrabold uppercase tracking-wider shadow">
                    ⭐ Premium
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                        <Star className="w-3.5 h-3.5 text-amber-400" />
                        ⭐ Premium
                      </span>
                      <span className="text-[11px] text-amber-400 font-semibold">C$50 – C$100 / mes</span>
                    </div>

                    <div>
                      <div className="flex items-baseline gap-1">
                        <span className="text-3xl font-extrabold text-amber-300">C$50</span>
                        <span className="text-xs text-slate-400">– C$100 / mes</span>
                      </div>
                      <p className="text-xs text-slate-300 mt-1">
                        Funciones adicionales, estrella dorada, fotos Ultra-HD y 50 GB de almacenamiento.
                      </p>
                    </div>

                    <div className="border-t border-slate-800/80 pt-3 space-y-2 text-xs text-slate-200">
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>Insignia dorada de Verificación ⭐</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>50 GB de almacenamiento en nube ☁️</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>Subida de fotos y videos Ultra-HD</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>Colores de globos y temas VIP</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>Transcripción de audios a texto</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-5 space-y-2">
                    <button
                      onClick={() => handleSelectPlan('premium_basic')}
                      className={`w-full py-2.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                        currentPlan === 'premium'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 cursor-default'
                          : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                      }`}
                    >
                      {currentPlan === 'premium' ? '✓ Premium Activo' : 'Activar Premium (C$50/mes)'}
                    </button>
                    <button
                      onClick={() => handleSelectPlan('premium_pro')}
                      className="w-full py-1.5 text-[11px] text-amber-400 hover:text-amber-300 underline font-medium text-center"
                    >
                      O plan VIP Pro con 50 GB (C$100/mes)
                    </button>
                  </div>
                </div>

                {/* 3. NEGOCIOS & COMERCIOS */}
                <div className="bg-gradient-to-b from-[#0c1e28] to-[#0a1622] border-2 border-emerald-500/40 rounded-2xl p-5 flex flex-col justify-between shadow-xl shadow-emerald-500/5 relative">
                  <div className="absolute -top-3 right-4 px-2.5 py-0.5 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-extrabold uppercase tracking-wider shadow">
                    🏪 Negocios
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                        <Store className="w-3.5 h-3.5 text-emerald-400" />
                        🏪 Comercial
                      </span>
                      <span className="text-[11px] text-emerald-400 font-semibold">C$100 – C$300 / mes</span>
                    </div>

                    <div>
                      <div className="flex items-baseline gap-1">
                        <span className="text-3xl font-extrabold text-emerald-300">C$100</span>
                        <span className="text-xs text-slate-400">– C$300 / mes</span>
                      </div>
                      <p className="text-xs text-slate-300 mt-1">
                        Perfil comercial, catálogo, 🤖 IA para atención 24/7 y anuncios en Estados.
                      </p>
                    </div>

                    <div className="border-t border-slate-800/80 pt-3 space-y-2 text-xs text-slate-200">
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>Perfil comercial con Catálogo digital</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>🤖 Asistente IA para atención y pedidos 24/7</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>Insignia oficial de Negocio Verificado ✅</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>📢 Anuncios en sección Estados/Descubrir</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span>15 a 100 GB de almacenamiento en nube ☁️</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-5 space-y-2">
                    <button
                      onClick={() => {
                        handleSelectPlan('business_pro');
                        setActiveTab('business');
                      }}
                      className={`w-full py-2.5 rounded-xl text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 ${
                        currentPlan === 'business'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 cursor-default'
                          : 'bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 shadow-md shadow-emerald-500/20'
                      }`}
                    >
                      {currentPlan === 'business' ? '✓ Negocio Activo' : 'Activar Negocio (C$100-300)'}
                    </button>
                    <button
                      onClick={() => setActiveTab('business')}
                      className="w-full py-1.5 text-[11px] text-emerald-400 hover:text-emerald-300 underline font-medium text-center"
                    >
                      Configurar Catálogo & Horarios
                    </button>
                  </div>
                </div>
              </div>

              {/* Payment Methods in Nicaragua */}
              <div className="bg-[#0b1322] border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-sky-400" />
                  <span>Métodos de Pago Nicaragüenses compatibles:</span>
                </div>
                <div className="flex flex-wrap items-center gap-2 text-[11px] font-semibold text-slate-300">
                  <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700">LAFISE Bancentro</span>
                  <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700">BAC Credomatic</span>
                  <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700">Billetera Banpro</span>
                  <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700">Tigo Money</span>
                  <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700">Efectivo contra entrega</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PERFIL COMERCIAL & CATÁLOGO */}
          {activeTab === 'business' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#0b1424] border border-slate-800 rounded-2xl p-4">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <Store className="w-5 h-5 text-emerald-400" />
                    Perfil Comercial para Negocios (C$100–300/mes)
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Permite a tus clientes consultar tus productos con precio en Córdobas (C$) y hacer pedidos directos por chat.
                  </p>
                </div>
                <button
                  onClick={handleSaveBusinessProfile}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs transition cursor-pointer shrink-0 shadow-lg shadow-emerald-500/20"
                >
                  Guardar Perfil Comercial
                </button>
              </div>

              {/* Business Info Form */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Nombre del Negocio / Empresa</label>
                  <input
                    type="text"
                    value={businessProfile.businessName}
                    onChange={(e) => setBusinessProfile({ ...businessProfile, businessName: e.target.value })}
                    placeholder="Ej. Comidería Doña Tania"
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Categoría</label>
                  <select
                    value={businessProfile.category}
                    onChange={(e) => setBusinessProfile({ ...businessProfile, category: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Comidería & Gastronomía">Comidería & Gastronomía Nica</option>
                    <option value="Moda, Ropa & Calzado">Moda, Ropa & Calzado</option>
                    <option value="Tecnología & Celulares">Tecnología & Celulares</option>
                    <option value="Pulpería & Abarrotes">Pulpería & Abarrotes</option>
                    <option value="Artesanías & Cultura">Artesanías de Masaya / Souvenirs</option>
                    <option value="Servicios Profesionales">Servicios Profesionales</option>
                    <option value="Farmacia & Salud">Farmacia & Salud</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Departamento / Ciudad</label>
                  <select
                    value={businessProfile.department}
                    onChange={(e) => setBusinessProfile({ ...businessProfile, department: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Managua">Managua</option>
                    <option value="Masaya">Masaya</option>
                    <option value="Granada">Granada</option>
                    <option value="León">León</option>
                    <option value="Chinandega">Chinandega</option>
                    <option value="Matagalpa">Matagalpa</option>
                    <option value="Estelí">Estelí</option>
                    <option value="Jinotega">Jinotega</option>
                    <option value="Rivas">Rivas / San Juan del Sur</option>
                    <option value="Carazo">Carazo</option>
                    <option value="Chontales">Chontales (Juigalpa)</option>
                    <option value="Caribe Norte">Caribe Norte (Bilwi)</option>
                    <option value="Caribe Sur">Caribe Sur (Bluefields)</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Horario de Atención</label>
                  <input
                    type="text"
                    value={businessProfile.hours}
                    onChange={(e) => setBusinessProfile({ ...businessProfile, hours: e.target.value })}
                    placeholder="Ej. Lunes a Sábado: 8am - 6pm"
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="md:col-span-2 space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Dirección Exacta</label>
                  <input
                    type="text"
                    value={businessProfile.address}
                    onChange={(e) => setBusinessProfile({ ...businessProfile, address: e.target.value })}
                    placeholder="Ej. De la rotonda El Güegüense 2c abajo, Managua"
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Product Catalog Section */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <ShoppingBag className="w-4 h-4 text-sky-400" />
                    Catálogo de Productos y Servicios ({businessProfile.catalog.length})
                  </h4>
                  <button
                    onClick={() => setShowAddProduct(true)}
                    className="px-3 py-1.5 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 border border-sky-500/30 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Agregar Producto</span>
                  </button>
                </div>

                {/* Add product modal/inline form */}
                {showAddProduct && (
                  <div className="p-4 bg-slate-900 border border-sky-500/40 rounded-2xl space-y-3 animate-in fade-in">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-sky-300">Nuevo Producto / Servicio para el Catálogo</span>
                      <button onClick={() => setShowAddProduct(false)} className="text-slate-400 hover:text-white">
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div className="sm:col-span-2 space-y-1">
                        <label className="text-[11px] text-slate-400">Título del producto</label>
                        <input
                          type="text"
                          value={newProductTitle}
                          onChange={(e) => setNewProductTitle(e.target.value)}
                          placeholder="Ej. Nacatamal Especial o Combo Familiar"
                          className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[11px] text-slate-400">Precio en Córdobas (C$)</label>
                        <input
                          type="number"
                          value={newProductPrice}
                          onChange={(e) => setNewProductPrice(Number(e.target.value))}
                          placeholder="180"
                          className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white"
                        />
                      </div>

                      <div className="sm:col-span-3 space-y-1">
                        <label className="text-[11px] text-slate-400">Descripción breve</label>
                        <input
                          type="text"
                          value={newProductDesc}
                          onChange={(e) => setNewProductDesc(e.target.value)}
                          placeholder="Ingredientes, garantía o detalles de entrega..."
                          className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-1">
                      <button
                        onClick={() => setShowAddProduct(false)}
                        className="px-3 py-1.5 rounded-xl text-slate-400 hover:text-white text-xs"
                      >
                        Cancelar
                      </button>
                      <button
                        onClick={handleAddProductToCatalog}
                        className="px-4 py-1.5 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs"
                      >
                        Guardar Producto
                      </button>
                    </div>
                  </div>
                )}

                {/* Catalog Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {businessProfile.catalog.map(item => (
                    <div key={item.id} className="bg-[#0b1424] border border-slate-800 rounded-2xl overflow-hidden flex flex-col justify-between group">
                      <div className="relative h-32 w-full overflow-hidden bg-slate-900">
                        <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-300" />
                        <span className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-slate-950/80 backdrop-blur-sm text-emerald-400 font-bold text-xs border border-emerald-500/30">
                          C${item.priceCordobas}
                        </span>
                      </div>
                      <div className="p-3 space-y-1.5">
                        <h5 className="text-xs font-bold text-white truncate">{item.title}</h5>
                        <p className="text-[11px] text-slate-400 line-clamp-2">{item.description}</p>
                        <div className="pt-2 flex items-center justify-between border-t border-slate-800/80">
                          <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                            En Existencia
                          </span>
                          <button
                            onClick={() => handleRemoveProduct(item.id)}
                            className="p-1 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition cursor-pointer"
                            title="Eliminar producto"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: IA PARA NEGOCIOS (24/7) */}
          {activeTab === 'ai' && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-sky-950/50 to-indigo-950/50 border border-sky-500/30 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <Bot className="w-5 h-5 text-sky-400" />
                    <h3 className="text-base font-bold text-white">
                      🤖 Asistente IA para Negocios (Respuestas Automáticas 24/7)
                    </h3>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 max-w-xl">
                    Atiende a tus clientes aunque estés durmiendo o fuera de línea. La IA responde precios de tu catálogo, horarios de atención, formas de pago (LAFISE, BAC) y toma pedidos automáticamente.
                  </p>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <span className="text-xs font-semibold text-slate-300">
                    {businessProfile.aiBotEnabled ? 'IA Activa 24/7' : 'IA Pausada'}
                  </span>
                  <button
                    onClick={() => {
                      const updated = { ...businessProfile, aiBotEnabled: !businessProfile.aiBotEnabled };
                      setBusinessProfile(updated);
                      onUpdateUser({ businessProfile: updated });
                    }}
                    className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                      businessProfile.aiBotEnabled ? 'bg-sky-500' : 'bg-slate-700'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white transition-transform transform shadow-sm ${
                        businessProfile.aiBotEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* Bot Configuration & Live Simulator Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                {/* Bot Settings */}
                <div className="bg-[#0b1424] border border-slate-800 rounded-2xl p-4 space-y-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-sky-400">
                    Configuración de Respuestas Automáticas
                  </h4>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">Mensaje de Bienvenida Automático</label>
                    <textarea
                      rows={2}
                      value={businessProfile.aiBotWelcomeMessage}
                      onChange={(e) => setBusinessProfile({ ...businessProfile, aiBotWelcomeMessage: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-sky-500 resize-none"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">Instrucciones del Bot / Sabor Nica</label>
                    <textarea
                      rows={2}
                      value={businessProfile.aiBotPrompt}
                      onChange={(e) => setBusinessProfile({ ...businessProfile, aiBotPrompt: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-sky-500 resize-none"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-300">Preguntas Frecuentes Configuradas</label>
                    <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                      {businessProfile.aiBotFaq?.map((faq, idx) => (
                        <div key={idx} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs">
                          <p className="font-semibold text-sky-300">Q: {faq.question}</p>
                          <p className="text-slate-400 mt-0.5 text-[11px]">R: {faq.answer}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={handleSaveBusinessProfile}
                    className="w-full py-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs transition cursor-pointer"
                  >
                    Guardar Parámetros de IA
                  </button>
                </div>

                {/* Live Simulator */}
                <div className="bg-[#0b1424] border border-slate-800 rounded-2xl flex flex-col overflow-hidden h-[380px]">
                  <div className="px-4 py-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="text-xs font-bold text-white">Simulador en Vivo de tu Asistente IA</span>
                    </div>
                    <span className="text-[10px] text-slate-400">Pruébalo como un cliente</span>
                  </div>

                  {/* Messages Feed */}
                  <div className="flex-1 p-3 overflow-y-auto space-y-2.5 text-xs bg-[#070e1a]/80">
                    {simulatedChatHistory.map((msg, i) => (
                      <div
                        key={i}
                        className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                      >
                        <div
                          className={`max-w-[85%] px-3 py-2 rounded-2xl ${
                            msg.sender === 'user'
                              ? 'bg-sky-600 text-white rounded-tr-none'
                              : 'bg-slate-800 text-slate-100 rounded-tl-none border border-slate-700/60'
                          }`}
                        >
                          <p>{msg.text}</p>
                        </div>
                        <span className="text-[9px] text-slate-500 mt-0.5 px-1">{msg.time}</span>
                      </div>
                    ))}
                  </div>

                  {/* Input form */}
                  <form onSubmit={handleSimulateAiResponse} className="p-2 border-t border-slate-800 bg-slate-900/90 flex gap-2">
                    <input
                      type="text"
                      value={testUserMessage}
                      onChange={(e) => setTestUserMessage(e.target.value)}
                      placeholder="Pregunta: ¿cuánto vale? ¿hacen envíos?"
                      className="flex-1 px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-sky-500"
                    />
                    <button
                      type="submit"
                      className="p-2 bg-sky-500 hover:bg-sky-600 text-white rounded-xl transition cursor-pointer"
                      title="Enviar mensaje de prueba"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: ANUNCIOS EN ESTADOS / DESCUBRIR */}
          {activeTab === 'ads' && (
            <div className="space-y-6">
              <div className="bg-[#0b1424] border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <Megaphone className="w-5 h-5 text-rose-400" />
                    <h3 className="text-base font-bold text-white">
                      📢 Publicidad y Anuncios Locales en Nicaragua
                    </h3>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 max-w-xl">
                    Los negocios pueden patrocinar historias o promociones en la sección de Estados y Canales para llegar a miles de usuarios activos en toda Nicaragua.
                  </p>
                </div>

                <div className="bg-rose-500/10 border border-rose-500/30 rounded-xl px-3 py-2 text-center shrink-0">
                  <span className="text-[10px] text-rose-300 uppercase font-semibold">Campaña Local</span>
                  <p className="text-sm font-bold text-white">Desde C$50 / 7 días</p>
                </div>
              </div>

              {/* Showcase Active Ads */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Anuncios Activos en Sección de Estados / Descubrir
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {INITIAL_SPONSORED_ADS.map(ad => (
                    <div key={ad.id} className="bg-[#0b1424] border border-slate-800 hover:border-slate-700 rounded-2xl overflow-hidden shadow-lg transition">
                      <div className="relative h-44 w-full">
                        <img src={ad.imageUrl} alt={ad.title} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                        
                        <div className="absolute top-3 left-3 flex items-center gap-2 bg-slate-950/70 backdrop-blur-md px-2.5 py-1 rounded-full border border-slate-700/80">
                          <img src={ad.businessAvatar} alt={ad.businessName} className="w-4 h-4 rounded-full object-cover" />
                          <span className="text-[11px] font-semibold text-white">{ad.businessName}</span>
                        </div>

                        {ad.discountBadge && (
                          <span className="absolute top-3 right-3 px-2 py-0.5 rounded-full bg-rose-500 text-white font-bold text-[10px] shadow">
                            {ad.discountBadge}
                          </span>
                        )}

                        <div className="absolute bottom-3 left-3 right-3">
                          <span className="text-[10px] font-semibold text-sky-400 uppercase tracking-wide">
                            {ad.businessCategory} • {ad.department}
                          </span>
                          <h5 className="text-sm font-bold text-white leading-tight mt-0.5">
                            {ad.title}
                          </h5>
                        </div>
                      </div>

                      <div className="p-4 space-y-3">
                        <p className="text-xs text-slate-300 leading-relaxed">
                          {ad.description}
                        </p>

                        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-3">
                          <span className="text-[11px] text-slate-400 flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5 text-slate-500" />
                            {ad.department}, Nicaragua
                          </span>

                          <button
                            onClick={() => {
                              onClose();
                              if (onOpenDirectChat) {
                                onOpenDirectChat('user-maria');
                              }
                            }}
                            className="px-3.5 py-1.5 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                            <span>{ad.ctaText}</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: VERIFICACIÓN OFICIAL */}
          {activeTab === 'verification' && (
            <div className="space-y-6">
              <div className="bg-[#0b1424] border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-sky-400" />
                    <h3 className="text-base font-bold text-white">
                      ✅ Insignia de Verificación Oficial en Naul Chat
                    </h3>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 max-w-xl">
                    Protege tu identidad o negocio. Las insignias verificadas garantizan autenticidad ante la comunidad nicaragüense y evitan la suplantación.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {currentUser.isVerified ? (
                    <span className="px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5">
                      <Check className="w-4 h-4 text-emerald-400" />
                      Cuenta Verificada 🇳🇮
                    </span>
                  ) : (
                    <span className="px-3 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold">
                      Sin Verificar
                    </span>
                  )}
                </div>
              </div>

              {/* Verification Request Form */}
              <form onSubmit={handleRequestVerification} className="bg-[#0b1424] border border-slate-800 rounded-2xl p-5 space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Solicitud de Insignia Verificada
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">Tipo de Verificación</label>
                    <select
                      value={verificationType}
                      onChange={(e) => setVerificationType(e.target.value as any)}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                    >
                      <option value="cedula">Cédula de Identidad de Nicaragua (Persona)</option>
                      <option value="ruc">Número RUC (Empresa o Negocio Registrado)</option>
                      <option value="business">Matrícula de Alcaldía / Negocio Local</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300">
                      {verificationType === 'cedula' ? 'Número de Cédula (001-XXXXXX-XXXX)' : 'Número de RUC o Matrícula'}
                    </label>
                    <input
                      type="text"
                      required
                      value={verificationDocNumber}
                      onChange={(e) => setVerificationDocNumber(e.target.value)}
                      placeholder={verificationType === 'cedula' ? '001-120590-0012X' : 'J0310000123456'}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-sky-500"
                    />
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">
                    La validación toma segundos en este entorno demostrativo y es permanente.
                  </span>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs transition cursor-pointer shadow-lg shadow-sky-500/20"
                  >
                    Obtener Insignia Verificada
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 6: ALMACENAMIENTO EN LA NUBE */}
          {activeTab === 'storage' && (
            <div className="space-y-6">
              <div className="bg-[#0b1424] border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <Cloud className="w-5 h-5 text-cyan-400" />
                    <h3 className="text-base font-bold text-white">
                      ☁️ Almacenamiento en la Nube de Naul Chat
                    </h3>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 max-w-xl">
                    Guarda tus fotos familiares, documentos importantes, audios y catálogos de negocio sin temor a perderlos.
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-2xl font-black text-cyan-300">{storageQuota.usedMb} MB</span>
                  <span className="text-xs text-slate-400"> de {(storageQuota.totalMb / 1024).toFixed(0)} GB ({storagePercent}%)</span>
                </div>
              </div>

              {/* Storage Visual Bar */}
              <div className="bg-[#0b1424] border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-slate-300">Capacidad en uso:</span>
                  <span className="text-cyan-400">{storagePercent}% utilizado</span>
                </div>

                <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden flex">
                  <div style={{ width: `${(storageQuota.photosMb / storageQuota.totalMb) * 100}%` }} className="h-full bg-sky-500" title="Fotos" />
                  <div style={{ width: `${(storageQuota.videosMb / storageQuota.totalMb) * 100}%` }} className="h-full bg-indigo-500" title="Videos" />
                  <div style={{ width: `${(storageQuota.audiosMb / storageQuota.totalMb) * 100}%` }} className="h-full bg-amber-500" title="Audios" />
                  <div style={{ width: `${(storageQuota.documentsMb / storageQuota.totalMb) * 100}%` }} className="h-full bg-emerald-500" title="Documentos" />
                </div>

                {/* Storage breakdown details */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-sky-500" />
                    <div>
                      <p className="text-[11px] text-slate-400">Fotos</p>
                      <p className="font-bold text-white">{storageQuota.photosMb} MB</p>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-indigo-500" />
                    <div>
                      <p className="text-[11px] text-slate-400">Videos</p>
                      <p className="font-bold text-white">{storageQuota.videosMb} MB</p>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-amber-500" />
                    <div>
                      <p className="text-[11px] text-slate-400">Notas de Voz</p>
                      <p className="font-bold text-white">{storageQuota.audiosMb} MB</p>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-emerald-500" />
                    <div>
                      <p className="text-[11px] text-slate-400">Documentos</p>
                      <p className="font-bold text-white">{storageQuota.documentsMb} MB</p>
                    </div>
                  </div>
                </div>

                <div className="border-t border-slate-800 pt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <p className="text-xs text-slate-400">
                    ¿Necesitas más espacio? Con el plan Premium obtienes 50 GB y con el plan Negocio hasta 100 GB.
                  </p>
                  <button
                    onClick={() => setActiveTab('plans')}
                    className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-bold text-xs transition cursor-pointer shrink-0 shadow-lg shadow-cyan-500/20"
                  >
                    Ampliar Almacenamiento
                  </button>
                </div>
              </div>

              {/* Cloud Backup & Google Drive Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/30 via-slate-900 to-cyan-950/30 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-400 shrink-0">
                    <Cloud className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      Copia de Seguridad en Google Drive
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
                        E2EE Cifrado
                      </span>
                    </h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Exporta tus chats cifrados a JSON o sincronízalos con Google Drive para no perder tus conversaciones.
                    </p>
                  </div>
                </div>
                {onOpenBackupRestore && (
                  <button
                    onClick={() => {
                      onClose();
                      onOpenBackupRestore('drive');
                    }}
                    className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition cursor-pointer shrink-0 shadow-lg"
                  >
                    Gestionar Respaldo
                  </button>
                )}
              </div>
            </div>
          )}

        </div>

        {/* Modal Bottom Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-[#070e1a] flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span>🇳🇮 Naul Chat Nicaragua</span>
            <span>•</span>
            <span className="text-slate-300 font-semibold">Precios en Córdobas (C$)</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition cursor-pointer font-medium"
          >
            Cerrar
          </button>
        </div>

      </div>
    </div>
  );
};
