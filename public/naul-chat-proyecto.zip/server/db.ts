import fs from 'fs';
import path from 'path';
import { MongoClient, Db } from 'mongodb';

export interface UserDoc {
  id: string;
  name: string;
  username: string;
  phone: string;
  email: string;
  passwordHash?: string;
  avatar: string;
  bio?: string;
  status?: string;
  isVerified: boolean;
  verificationType?: string;
  bubbleColors?: any;
  createdAt: number;
  updatedAt?: number;
}

export interface MessageDoc {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  type: 'text' | 'image' | 'audio' | 'video' | 'file' | 'location';
  content: string;
  timestamp: number;
  status: 'sent' | 'delivered' | 'read';
  isEncrypted: boolean;
  mediaUrl?: string;
  audioMetadata?: {
    duration: number;
    waveform?: number[];
  };
  fileMetadata?: {
    fileName: string;
    fileSize: string;
    fileType: string;
  };
  locationMetadata?: {
    latitude: number;
    longitude: number;
    address?: string;
  };
  replyTo?: {
    id: string;
    senderName: string;
    text: string;
  };
  isEdited?: boolean;
  isDeleted?: boolean;
  reactions?: Record<string, string[]>;
  caption?: string;
  iv?: string;
  algorithm?: string;
  cipherPayload?: string;
}

export interface ConversationDoc {
  id: string;
  type: 'direct' | 'group' | 'channel' | 'community';
  name: string;
  avatar: string;
  participants: UserDoc[];
  participantIds: string[];
  unreadCount: number;
  lastMessage?: MessageDoc;
  isVerified?: boolean;
  isPinned?: boolean;
  category?: string;
  createdAt: number;
  updatedAt: number;
}

export interface StatusDoc {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video' | 'text';
  audioTrack?: {
    title: string;
    artist?: string;
    url?: string;
  };
  text?: string;
  bgColor?: string;
  timestamp: number;
  expiresAt: number;
  viewsCount: number;
  viewers?: Array<{
    userId: string;
    userName: string;
    userAvatar: string;
    timestamp: number;
  }>;
}

export interface OtpDoc {
  id: string;
  target: string; // phone or email
  code: string;
  expiresAt: number;
  verified: boolean;
  createdAt: number;
}

export interface SessionDoc {
  id: string;
  userId: string;
  deviceName: string;
  ipAddress: string;
  userAgent: string;
  tokenSignature?: string;
  createdAt: number;
  lastActiveAt: number;
  isValid: boolean;
}

export interface StoredFileDoc {
  id: string;
  userId: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  filePath?: string;
  isPrivate: boolean;
  createdAt: number;
}

export interface ContactDoc {
  id: string;
  userId: string; // The user who saved this contact
  contactUserId: string; // The user or profile being saved
  name: string;
  phone: string;
  email: string;
  avatar?: string;
  bio?: string;
  conversationId?: string;
  createdAt: number;
}

export interface BlockDoc {
  id: string;
  userId: string;        // Usuario que realiza el bloqueo
  blockedUserId: string; // Usuario bloqueado
  name: string;
  phone?: string;
  avatar?: string;
  reason?: string;
  blockedAt: number;
}

interface LocalDBData {
  users: UserDoc[];
  conversations: ConversationDoc[];
  messages: MessageDoc[];
  statuses: StatusDoc[];
  otps: OtpDoc[];
  sessions: SessionDoc[];
  storedFiles: StoredFileDoc[];
  contacts: ContactDoc[];
  blockedUsers?: BlockDoc[];
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'naul_mongodb.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

let mongoClient: MongoClient | null = null;
let mongoDb: Db | null = null;
let isUsingRemoteMongo = false;

// Initial Seed Data
const SEED_USERS: UserDoc[] = [
  {
    id: 'user-me',
    name: 'Norman Escobar',
    username: '@normanescobar',
    phone: '+505 8899 4432',
    email: 'normanescobar804@gmail.com',
    passwordHash: '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', // 'admin123'
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    bio: 'La disciplina te lleva lejos. 💪',
    status: 'online',
    isVerified: true,
    verificationType: 'official',
    createdAt: Date.now() - 30 * 86400000,
  },
  {
    id: 'user-yuri',
    name: 'Yuri',
    username: '@yuri_nica',
    phone: '+505 7766 5544',
    email: 'yuri@naulchat.ni',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80',
    bio: 'Nicaragua siempre conectada 🇳🇮',
    status: 'online',
    isVerified: true,
    verificationType: 'official',
    createdAt: Date.now() - 25 * 86400000,
  },
  {
    id: 'user-carlos',
    name: 'Carlos Mendoza',
    username: '@carlos_m',
    phone: '+505 8822 1199',
    email: 'carlos@managua.ni',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
    bio: 'Beisbol, café y desarrollo en Managua ⚾☕',
    status: 'offline',
    isVerified: true,
    verificationType: 'identity',
    createdAt: Date.now() - 20 * 86400000,
  },
  {
    id: 'user-sofia',
    name: 'Dra. Sofía Mendoza',
    username: '@sofia_medica',
    phone: '+505 8872 3410',
    email: 'dra.sofiamendoza@salud.org.ni',
    avatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&auto=format&fit=crop&q=80',
    bio: 'Médico General • Consultas y prevención • Managua 🩺🇳🇮',
    status: 'online',
    isVerified: true,
    verificationType: 'official',
    createdAt: Date.now() - 15 * 86400000,
  },
  {
    id: 'user-kevin',
    name: 'Ing. Kevin Talavera',
    username: '@kevin_talavera',
    phone: '+505 8421 9901',
    email: 'kevin.talavera@ingenieria.ni',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
    bio: 'Ingeniero en Computación y Telecomunicaciones • León 💻⚡',
    status: 'online',
    isVerified: true,
    verificationType: 'identity',
    createdAt: Date.now() - 12 * 86400000,
  },
  {
    id: 'user-elena',
    name: 'Elena Blandón',
    username: '@elena_matagalpa',
    phone: '+505 8654 2210',
    email: 'elena.cafe@matagalpa.ni',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80',
    bio: 'Producción y exportación de café de altura • Matagalpa ☕🌿',
    status: 'away',
    isVerified: true,
    verificationType: 'identity',
    createdAt: Date.now() - 10 * 86400000,
  },
  {
    id: 'user-lucia',
    name: 'Lucía Chamorro',
    username: '@lucia_chamorro',
    phone: '+505 7812 4589',
    email: 'lucia.chamorro@arte.ni',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&auto=format&fit=crop&q=80',
    bio: 'Diseño de marcas y proyectos culturales • Granada 🎨✨',
    status: 'online',
    isVerified: true,
    verificationType: 'official',
    createdAt: Date.now() - 8 * 86400000,
  },
  {
    id: 'user-marlon',
    name: 'Marlon Jarquín',
    username: '@marlon_esteli',
    phone: '+505 8933 1450',
    email: 'marlon.fitness@esteli.ni',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
    bio: 'Entrenador deportivo y nutrición • Estelí 🏋️‍♂️⚽',
    status: 'offline',
    isVerified: true,
    verificationType: 'identity',
    createdAt: Date.now() - 7 * 86400000,
  },
  {
    id: 'user-francisco',
    name: 'Don Francisco Rivas',
    username: '@francisco_masaya',
    phone: '+505 8701 5562',
    email: 'artesanias.rivas@masaya.com.ni',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&auto=format&fit=crop&q=80',
    bio: 'Comercio local y artesanías de Masaya 🏺🪵',
    status: 'online',
    isVerified: true,
    verificationType: 'official',
    createdAt: Date.now() - 6 * 86400000,
  },
  {
    id: 'user-marcela',
    name: 'Dra. Marcela Somarriba',
    username: '@marcela_dental',
    phone: '+505 8599 3012',
    email: 'clinica.somarriba@managua.ni',
    avatar: 'https://images.unsplash.com/photo-1594824813576-905792c30089?w=400&auto=format&fit=crop&q=80',
    bio: 'Odontología integral y estética dental • Managua 🦷✨',
    status: 'online',
    isVerified: true,
    verificationType: 'identity',
    createdAt: Date.now() - 5 * 86400000,
  },
  {
    id: 'user-cruz-blanca',
    name: 'Cruz Blanca Nicaragüense (128)',
    username: '@cruzblanca_128',
    phone: '+505 2265 1419',
    email: 'emergencias@cruzblanca.org.ni',
    avatar: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=400&auto=format&fit=crop&q=80',
    bio: 'Ambulancias y atención médica prehospitalaria • Emergencias 128 🚑🚨',
    status: 'online',
    isVerified: true,
    verificationType: 'official',
    createdAt: Date.now() - 30 * 86400000,
  },
  {
    id: 'user-bomberos',
    name: 'Bomberos Unificados de Nicaragua (115)',
    username: '@bomberos_115',
    phone: '+505 2264 0244',
    email: 'contacto@bomberos.gob.ni',
    avatar: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=400&auto=format&fit=crop&q=80',
    bio: 'Prevención, rescate y combate de incendios • Línea de Emergencia 115 🚒🔥',
    status: 'online',
    isVerified: true,
    verificationType: 'official',
    createdAt: Date.now() - 30 * 86400000,
  },
  {
    id: 'user-enacal',
    name: 'ENACAL Oficial (127)',
    username: '@enacal_127',
    phone: '+505 2266 7777',
    email: 'atencion@enacal.gob.ni',
    avatar: 'https://images.unsplash.com/photo-1541888946425-d0fbb18086f6?w=400&auto=format&fit=crop&q=80',
    bio: 'Empresa Nicaragüense de Acueductos y Alcantarillados • Línea 127 💧🚰',
    status: 'online',
    isVerified: true,
    verificationType: 'official',
    createdAt: Date.now() - 30 * 86400000,
  }
];

const SEED_CONVERSATIONS: ConversationDoc[] = [
  {
    id: 'conv-yuri',
    type: 'direct',
    name: 'Yuri',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80',
    participants: [SEED_USERS[0], SEED_USERS[1]],
    participantIds: ['user-me', 'user-yuri'],
    unreadCount: 0,
    isVerified: true,
    isPinned: true,
    category: 'Oficial',
    createdAt: Date.now() - 10 * 86400000,
    updatedAt: Date.now(),
    lastMessage: {
      id: 'msg-seed-1',
      conversationId: 'conv-yuri',
      senderId: 'user-yuri',
      senderName: 'Yuri',
      senderAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80',
      type: 'text',
      content: '¡Quedó súper nítido el backend con base de datos real en Naul Chat! 🇳🇮🚀',
      timestamp: Date.now() - 120000,
      status: 'read',
      isEncrypted: true
    }
  },
  {
    id: 'conv-comunidad-nica',
    type: 'community',
    name: 'Comunidad Nacional 🇳🇮',
    avatar: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400&auto=format&fit=crop&q=80',
    participants: [SEED_USERS[0], SEED_USERS[1], SEED_USERS[2]],
    participantIds: ['user-me', 'user-yuri', 'user-carlos'],
    unreadCount: 2,
    isVerified: true,
    isPinned: true,
    category: 'Comunidades',
    createdAt: Date.now() - 5 * 86400000,
    updatedAt: Date.now() - 3600000,
    lastMessage: {
      id: 'msg-seed-2',
      conversationId: 'conv-comunidad-nica',
      senderId: 'user-carlos',
      senderName: 'Carlos Mendoza',
      senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
      type: 'text',
      content: '¡Bienvenidos a la red nicaragüense con estados de fotos, videos y música! 🎵',
      timestamp: Date.now() - 3600000,
      status: 'read',
      isEncrypted: true
    }
  }
];

const SEED_MESSAGES: MessageDoc[] = [
  {
    id: 'msg-yuri-1',
    conversationId: 'conv-yuri',
    senderId: 'user-yuri',
    senderName: 'Yuri',
    senderAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80',
    type: 'text',
    content: 'Hola Norman, bienvenido a la red de Naul Chat Nicaragua. Todo cifrado y seguro.',
    timestamp: Date.now() - 600000,
    status: 'read',
    isEncrypted: true
  },
  {
    id: 'msg-yuri-2',
    conversationId: 'conv-yuri',
    senderId: 'user-me',
    senderName: 'Norman Escobar',
    senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    type: 'text',
    content: 'Excelente Yuri, ya tenemos Node.js con base de datos conectada.',
    timestamp: Date.now() - 300000,
    status: 'read',
    isEncrypted: true
  },
  {
    id: 'msg-seed-1',
    conversationId: 'conv-yuri',
    senderId: 'user-yuri',
    senderName: 'Yuri',
    senderAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80',
    type: 'text',
    content: '¡Quedó súper nítido el backend con base de datos real en Naul Chat! 🇳🇮🚀',
    timestamp: Date.now() - 120000,
    status: 'read',
    isEncrypted: true
  }
];

const SEED_STATUSES: StatusDoc[] = [
  {
    id: 'status-yuri-1',
    userId: 'user-yuri',
    userName: 'Yuri',
    userAvatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
    mediaUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80',
    mediaType: 'image',
    audioTrack: {
      title: 'Nicaragua Mía',
      artist: 'Tino López Guerra',
      url: 'https://cdn.freesound.org/previews/518/518888_6142149-lq.mp3'
    },
    text: 'Fin de semana en San Juan del Sur 🏖️🇳🇮',
    timestamp: Date.now() - 3600000 * 2,
    expiresAt: Date.now() + 3600000 * 22,
    viewsCount: 42
  },
  {
    id: 'status-carlos-1',
    userId: 'user-carlos',
    userName: 'Carlos Mendoza',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    mediaUrl: 'https://images.unsplash.com/photo-1518638150340-f706e86654de?w=800&auto=format&fit=crop&q=80',
    mediaType: 'image',
    audioTrack: {
      title: 'Son Nica Tradicional',
      artist: 'Camilo Zapata',
      url: 'https://cdn.freesound.org/previews/456/456123_5121236-lq.mp3'
    },
    text: 'Listos para el clásico de béisbol en el Estadio Nacional Denis Martínez ⚾🇳🇮',
    timestamp: Date.now() - 3600000 * 5,
    expiresAt: Date.now() + 3600000 * 19,
    viewsCount: 65
  }
];

// Helper to read local data
function readLocalData(): LocalDBData {
  if (!fs.existsSync(DATA_FILE)) {
    const initial: LocalDBData = {
      users: SEED_USERS,
      conversations: SEED_CONVERSATIONS,
      messages: SEED_MESSAGES,
      statuses: SEED_STATUSES,
      otps: [],
      sessions: [],
      storedFiles: [],
      contacts: []
    };
    fs.writeFileSync(DATA_FILE, JSON.stringify(initial, null, 2), 'utf-8');
    return initial;
  }
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    const data: LocalDBData = JSON.parse(raw);
    if (!data.sessions) data.sessions = [];
    if (!data.storedFiles) data.storedFiles = [];
    if (!data.otps) data.otps = [];
    if (!data.contacts) data.contacts = [];
    return data;
  } catch (err) {
    console.error('Error reading local db file:', err);
    return {
      users: SEED_USERS,
      conversations: SEED_CONVERSATIONS,
      messages: SEED_MESSAGES,
      statuses: SEED_STATUSES,
      otps: [],
      sessions: [],
      storedFiles: [],
      contacts: []
    };
  }
}

// Helper to write local data
function writeLocalData(data: LocalDBData): void {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing local db file:', err);
  }
}

// Init Database connection
export async function initDatabase(): Promise<{ isRemote: boolean }> {
  const uri = process.env.MONGODB_URI;
  if (uri && uri.trim().startsWith('mongodb')) {
    try {
      console.log('Connecting to remote MongoDB URI...');
      mongoClient = new MongoClient(uri);
      await mongoClient.connect();
      mongoDb = mongoClient.db('naulchat');
      isUsingRemoteMongo = true;
      console.log('Successfully connected to MongoDB Atlas / cluster');
      return { isRemote: true };
    } catch (err) {
      console.warn('Could not connect to remote MongoDB URI, falling back to local MongoDB persistent document store:', err);
    }
  }

  // Use local persistent document database
  readLocalData();
  console.log(`Using persistent local MongoDB-compatible document database at ${DATA_FILE}`);
  return { isRemote: false };
}

// User Operations
export async function dbFindUser(query: { id?: string; phone?: string; email?: string; username?: string }): Promise<UserDoc | null> {
  if (isUsingRemoteMongo && mongoDb) {
    const filter: Record<string, unknown> = {};
    if (query.id) filter.id = query.id;
    if (query.phone) filter.phone = query.phone;
    if (query.email) filter.email = query.email;
    if (query.username) filter.username = query.username;
    const res = await mongoDb.collection<UserDoc>('users').findOne(filter);
    return res;
  }

  const data = readLocalData();
  const found = data.users.find(u => {
    if (query.id && u.id === query.id) return true;
    if (query.phone && u.phone === query.phone) return true;
    if (query.email && u.email?.toLowerCase() === query.email.toLowerCase()) return true;
    if (query.username && u.username?.toLowerCase() === query.username.toLowerCase()) return true;
    return false;
  });
  return found || null;
}

export async function dbFindUserByLogin(identifier: string): Promise<UserDoc | null> {
  const clean = identifier.trim().toLowerCase();
  if (isUsingRemoteMongo && mongoDb) {
    const user = await mongoDb.collection<UserDoc>('users').findOne({
      $or: [
        { email: clean },
        { phone: identifier.trim() },
        { username: clean.startsWith('@') ? clean : `@${clean}` }
      ]
    });
    return user;
  }

  const data = readLocalData();
  const user = data.users.find(u => 
    u.email?.toLowerCase() === clean ||
    u.phone?.replace(/\s+/g, '') === identifier.replace(/\s+/g, '') ||
    u.username?.toLowerCase() === clean ||
    u.username?.toLowerCase() === `@${clean}`
  );
  return user || null;
}

export async function dbCreateUser(user: UserDoc): Promise<UserDoc> {
  if (isUsingRemoteMongo && mongoDb) {
    await mongoDb.collection<UserDoc>('users').insertOne({ ...user });
    return user;
  }

  const data = readLocalData();
  data.users.push(user);
  writeLocalData(data);
  return user;
}

export async function dbUpdateUser(userId: string, updates: Partial<UserDoc>): Promise<UserDoc | null> {
  if (isUsingRemoteMongo && mongoDb) {
    await mongoDb.collection<UserDoc>('users').updateOne({ id: userId }, { $set: updates });
    return dbFindUser({ id: userId });
  }

  const data = readLocalData();
  const idx = data.users.findIndex(u => u.id === userId);
  if (idx === -1) return null;
  data.users[idx] = { ...data.users[idx], ...updates, updatedAt: Date.now() };
  writeLocalData(data);
  return data.users[idx];
}

export async function dbListUsers(): Promise<UserDoc[]> {
  if (isUsingRemoteMongo && mongoDb) {
    return await mongoDb.collection<UserDoc>('users').find({}).toArray();
  }
  return readLocalData().users;
}

// Conversations Operations
export async function dbListConversations(userId: string): Promise<ConversationDoc[]> {
  if (isUsingRemoteMongo && mongoDb) {
    const list = await mongoDb.collection<ConversationDoc>('conversations')
      .find({ participantIds: userId })
      .sort({ updatedAt: -1 })
      .toArray();
    return list;
  }

  const data = readLocalData();
  // Return conversations where user participates, sorted by recent activity
  return data.conversations
    .filter(c => c.participantIds.includes(userId) || c.type === 'community' || c.type === 'channel')
    .sort((a, b) => b.updatedAt - a.updatedAt);
}

export async function dbGetConversation(convId: string): Promise<ConversationDoc | null> {
  if (isUsingRemoteMongo && mongoDb) {
    return await mongoDb.collection<ConversationDoc>('conversations').findOne({ id: convId });
  }
  const data = readLocalData();
  return data.conversations.find(c => c.id === convId) || null;
}

export async function dbCreateConversation(conv: ConversationDoc): Promise<ConversationDoc> {
  if (isUsingRemoteMongo && mongoDb) {
    await mongoDb.collection<ConversationDoc>('conversations').insertOne({ ...conv });
    return conv;
  }

  const data = readLocalData();
  const existing = data.conversations.find(c => c.id === conv.id);
  if (existing) return existing;
  data.conversations.unshift(conv);
  writeLocalData(data);
  return conv;
}

export async function dbDeleteConversation(convId: string, userId: string): Promise<boolean> {
  if (isUsingRemoteMongo && mongoDb) {
    const res = await mongoDb.collection<ConversationDoc>('conversations').deleteOne({ 
      id: convId, 
      $or: [
        { participantIds: userId },
        { type: 'community' },
        { type: 'channel' }
      ]
    });
    await mongoDb.collection<MessageDoc>('messages').deleteMany({ conversationId: convId });
    return res.deletedCount > 0;
  }

  const data = readLocalData();
  const initialLen = data.conversations.length;
  data.conversations = data.conversations.filter(c => !(c.id === convId && (c.participantIds.includes(userId) || c.type === 'community' || c.type === 'channel')));
  data.messages = data.messages.filter(m => m.conversationId !== convId);
  if (data.conversations.length !== initialLen) {
    writeLocalData(data);
    return true;
  }
  return false;
}

// Messages Operations
export async function dbGetMessages(convId: string, limit = 100): Promise<MessageDoc[]> {
  if (isUsingRemoteMongo && mongoDb) {
    return await mongoDb.collection<MessageDoc>('messages')
      .find({ conversationId: convId })
      .sort({ timestamp: 1 })
      .limit(limit)
      .toArray();
  }

  const data = readLocalData();
  return data.messages
    .filter(m => m.conversationId === convId)
    .sort((a, b) => a.timestamp - b.timestamp)
    .slice(-limit);
}

export async function dbSaveMessage(msg: MessageDoc): Promise<MessageDoc> {
  if (isUsingRemoteMongo && mongoDb) {
    await mongoDb.collection<MessageDoc>('messages').insertOne({ ...msg });
    await mongoDb.collection<ConversationDoc>('conversations').updateOne(
      { id: msg.conversationId },
      { $set: { lastMessage: msg, updatedAt: msg.timestamp } }
    );
    return msg;
  }

  const data = readLocalData();
  data.messages.push(msg);
  const convIdx = data.conversations.findIndex(c => c.id === msg.conversationId);
  if (convIdx !== -1) {
    data.conversations[convIdx].lastMessage = msg;
    data.conversations[convIdx].updatedAt = msg.timestamp;
  }
  writeLocalData(data);
  return msg;
}

export async function dbEditMessage(convId: string, msgId: string, newText: string): Promise<boolean> {
  if (isUsingRemoteMongo && mongoDb) {
    const res = await mongoDb.collection<MessageDoc>('messages').updateOne(
      { id: msgId, conversationId: convId },
      { $set: { content: newText, isEdited: true } }
    );
    return res.modifiedCount > 0;
  }

  const data = readLocalData();
  const m = data.messages.find(msg => msg.id === msgId && msg.conversationId === convId);
  if (!m) return false;
  m.content = newText;
  m.isEdited = true;
  writeLocalData(data);
  return true;
}

export async function dbDeleteMessage(convId: string, msgId: string): Promise<boolean> {
  if (isUsingRemoteMongo && mongoDb) {
    const res = await mongoDb.collection<MessageDoc>('messages').updateOne(
      { id: msgId, conversationId: convId },
      { $set: { content: 'Este mensaje fue eliminado', isDeleted: true } }
    );
    return res.modifiedCount > 0;
  }

  const data = readLocalData();
  const m = data.messages.find(msg => msg.id === msgId && msg.conversationId === convId);
  if (!m) return false;
  m.content = 'Este mensaje fue eliminado';
  m.isDeleted = true;
  writeLocalData(data);
  return true;
}

export async function dbUpdateMessageReactions(convId: string, msgId: string, reactions: Record<string, string[]>): Promise<boolean> {
  if (isUsingRemoteMongo && mongoDb) {
    const res = await mongoDb.collection<MessageDoc>('messages').updateOne(
      { id: msgId, conversationId: convId },
      { $set: { reactions } }
    );
    return res.modifiedCount > 0;
  }

  const data = readLocalData();
  const m = data.messages.find(msg => msg.id === msgId && msg.conversationId === convId);
  if (!m) return false;
  m.reactions = reactions;
  writeLocalData(data);
  return true;
}

export async function dbMarkMessagesAsRead(convId: string, readerUserId: string): Promise<string[]> {
  const updatedMessageIds: string[] = [];

  if (isUsingRemoteMongo && mongoDb) {
    const unreadMsgs = await mongoDb.collection<MessageDoc>('messages')
      .find({ conversationId: convId, senderId: { $ne: readerUserId }, status: { $ne: 'read' } })
      .toArray();

    for (const msg of unreadMsgs) {
      updatedMessageIds.push(msg.id);
    }

    if (updatedMessageIds.length > 0) {
      await mongoDb.collection<MessageDoc>('messages').updateMany(
        { id: { $in: updatedMessageIds } },
        { $set: { status: 'read' } }
      );
      await mongoDb.collection<ConversationDoc>('conversations').updateOne(
        { id: convId },
        { $set: { unreadCount: 0 } }
      );
    }
    return updatedMessageIds;
  }

  const data = readLocalData();
  data.messages.forEach(msg => {
    if (msg.conversationId === convId && msg.senderId !== readerUserId && msg.status !== 'read') {
      msg.status = 'read';
      updatedMessageIds.push(msg.id);
    }
  });

  const conv = data.conversations.find(c => c.id === convId);
  if (conv) {
    conv.unreadCount = 0;
    if (conv.lastMessage && conv.lastMessage.senderId !== readerUserId) {
      conv.lastMessage.status = 'read';
    }
  }

  if (updatedMessageIds.length > 0) {
    writeLocalData(data);
  }
  return updatedMessageIds;
}

// Statuses / Historias Operations
export async function dbListStatuses(): Promise<StatusDoc[]> {
  const cutoff = Date.now() - 24 * 3600 * 1000;
  if (isUsingRemoteMongo && mongoDb) {
    return await mongoDb.collection<StatusDoc>('statuses')
      .find({ timestamp: { $gte: cutoff } })
      .sort({ timestamp: -1 })
      .toArray();
  }

  const data = readLocalData();
  return data.statuses
    .filter(s => s.timestamp >= cutoff)
    .sort((a, b) => b.timestamp - a.timestamp);
}

export async function dbCreateStatus(status: StatusDoc): Promise<StatusDoc> {
  if (isUsingRemoteMongo && mongoDb) {
    await mongoDb.collection<StatusDoc>('statuses').insertOne({ ...status });
    return status;
  }

  const data = readLocalData();
  data.statuses.unshift(status);
  writeLocalData(data);
  return status;
}

export async function dbRecordStatusView(statusId: string, viewer: { userId: string; userName: string; userAvatar: string }): Promise<StatusDoc | null> {
  if (isUsingRemoteMongo && mongoDb) {
    await mongoDb.collection<StatusDoc>('statuses').updateOne(
      { id: statusId, 'viewers.userId': { $ne: viewer.userId } },
      {
        $inc: { viewsCount: 1 },
        $push: { viewers: { ...viewer, timestamp: Date.now() } } as any
      }
    );
    return await mongoDb.collection<StatusDoc>('statuses').findOne({ id: statusId });
  }

  const data = readLocalData();
  const status = data.statuses.find(s => s.id === statusId);
  if (!status) return null;

  if (!status.viewers) status.viewers = [];
  const alreadyViewed = status.viewers.some(v => v.userId === viewer.userId);
  if (!alreadyViewed && viewer.userId !== status.userId) {
    status.viewsCount = (status.viewsCount || 0) + 1;
    status.viewers.push({
      ...viewer,
      timestamp: Date.now()
    });
    writeLocalData(data);
  }
  return status;
}

// OTP Verification Operations
export async function dbCreateOtp(target: string, code: string): Promise<OtpDoc> {
  const otp: OtpDoc = {
    id: `otp-${Date.now()}`,
    target: target.trim(),
    code,
    expiresAt: Date.now() + 10 * 60 * 1000, // 10 minutes validity
    verified: false,
    createdAt: Date.now()
  };

  if (isUsingRemoteMongo && mongoDb) {
    await mongoDb.collection<OtpDoc>('otps').insertOne({ ...otp });
    return otp;
  }

  const data = readLocalData();
  data.otps.push(otp);
  writeLocalData(data);
  return otp;
}

export async function dbVerifyOtp(target: string, code: string): Promise<boolean> {
  const now = Date.now();
  if (isUsingRemoteMongo && mongoDb) {
    const doc = await mongoDb.collection<OtpDoc>('otps').findOne({
      target: target.trim(),
      code: code.trim(),
      expiresAt: { $gte: now },
      verified: false
    });
    if (!doc) return false;
    await mongoDb.collection<OtpDoc>('otps').updateOne({ id: doc.id }, { $set: { verified: true } });
    return true;
  }

  const data = readLocalData();
  const idx = data.otps.findIndex(o => 
    o.target.trim().toLowerCase() === target.trim().toLowerCase() && 
    o.code.trim() === code.trim() && 
    o.expiresAt >= now && 
    !o.verified
  );
  if (idx === -1) return false;
  data.otps[idx].verified = true;
  writeLocalData(data);
  return true;
}

// Session Management Operations
export async function dbCreateSession(session: SessionDoc): Promise<SessionDoc> {
  if (isUsingRemoteMongo && mongoDb) {
    await mongoDb.collection<SessionDoc>('sessions').insertOne({ ...session });
    return session;
  }

  const data = readLocalData();
  if (!data.sessions) data.sessions = [];
  data.sessions.push(session);
  writeLocalData(data);
  return session;
}

export async function dbFindSession(sessionId: string): Promise<SessionDoc | null> {
  if (isUsingRemoteMongo && mongoDb) {
    return await mongoDb.collection<SessionDoc>('sessions').findOne({ id: sessionId, isValid: true });
  }

  const data = readLocalData();
  return data.sessions?.find(s => s.id === sessionId && s.isValid) || null;
}

export async function dbListUserSessions(userId: string): Promise<SessionDoc[]> {
  if (isUsingRemoteMongo && mongoDb) {
    return await mongoDb.collection<SessionDoc>('sessions')
      .find({ userId, isValid: true })
      .sort({ lastActiveAt: -1 })
      .toArray();
  }

  const data = readLocalData();
  return (data.sessions || [])
    .filter(s => s.userId === userId && s.isValid)
    .sort((a, b) => b.lastActiveAt - a.lastActiveAt);
}

export async function dbTouchSession(sessionId: string): Promise<void> {
  const now = Date.now();
  if (isUsingRemoteMongo && mongoDb) {
    await mongoDb.collection<SessionDoc>('sessions').updateOne(
      { id: sessionId },
      { $set: { lastActiveAt: now } }
    );
    return;
  }

  const data = readLocalData();
  const sess = data.sessions?.find(s => s.id === sessionId);
  if (sess) {
    sess.lastActiveAt = now;
    writeLocalData(data);
  }
}

export async function dbRevokeSession(sessionId: string, userId: string): Promise<boolean> {
  if (isUsingRemoteMongo && mongoDb) {
    const res = await mongoDb.collection<SessionDoc>('sessions').updateOne(
      { id: sessionId, userId },
      { $set: { isValid: false } }
    );
    return res.modifiedCount > 0;
  }

  const data = readLocalData();
  const sess = data.sessions?.find(s => s.id === sessionId && s.userId === userId);
  if (!sess) return false;
  sess.isValid = false;
  writeLocalData(data);
  return true;
}

export async function dbRevokeAllOtherSessions(userId: string, currentSessionId: string): Promise<number> {
  if (isUsingRemoteMongo && mongoDb) {
    const res = await mongoDb.collection<SessionDoc>('sessions').updateMany(
      { userId, id: { $ne: currentSessionId }, isValid: true },
      { $set: { isValid: false } }
    );
    return res.modifiedCount;
  }

  const data = readLocalData();
  let count = 0;
  if (data.sessions) {
    data.sessions.forEach(s => {
      if (s.userId === userId && s.id !== currentSessionId && s.isValid) {
        s.isValid = false;
        count++;
      }
    });
    if (count > 0) writeLocalData(data);
  }
  return count;
}

// Stored Files Operations
export async function dbSaveStoredFile(file: StoredFileDoc): Promise<StoredFileDoc> {
  if (isUsingRemoteMongo && mongoDb) {
    await mongoDb.collection<StoredFileDoc>('storedFiles').insertOne({ ...file });
    return file;
  }

  const data = readLocalData();
  if (!data.storedFiles) data.storedFiles = [];
  data.storedFiles.push(file);
  writeLocalData(data);
  return file;
}

export async function dbGetStoredFile(fileId: string): Promise<StoredFileDoc | null> {
  if (isUsingRemoteMongo && mongoDb) {
    return await mongoDb.collection<StoredFileDoc>('storedFiles').findOne({ id: fileId });
  }

  const data = readLocalData();
  return data.storedFiles?.find(f => f.id === fileId) || null;
}

// Contacts Operations
export async function dbListContacts(userId: string): Promise<ContactDoc[]> {
  if (isUsingRemoteMongo && mongoDb) {
    return await mongoDb.collection<ContactDoc>('contacts')
      .find({ userId })
      .sort({ createdAt: -1 })
      .toArray();
  }

  const data = readLocalData();
  if (!data.contacts) data.contacts = [];
  return data.contacts
    .filter(c => c.userId === userId)
    .sort((a, b) => b.createdAt - a.createdAt);
}

export async function dbSaveContact(contact: ContactDoc): Promise<ContactDoc> {
  if (isUsingRemoteMongo && mongoDb) {
    const existing = await mongoDb.collection<ContactDoc>('contacts').findOne({
      userId: contact.userId,
      $or: [
        { contactUserId: contact.contactUserId },
        { phone: contact.phone },
        ...(contact.email ? [{ email: contact.email }] : [])
      ]
    });

    if (existing) {
      await mongoDb.collection<ContactDoc>('contacts').updateOne(
        { id: existing.id },
        { $set: { ...contact, id: existing.id } }
      );
      return { ...contact, id: existing.id };
    }

    await mongoDb.collection<ContactDoc>('contacts').insertOne({ ...contact });
    return contact;
  }

  const data = readLocalData();
  if (!data.contacts) data.contacts = [];

  const existingIdx = data.contacts.findIndex(c => 
    c.userId === contact.userId && (
      c.contactUserId === contact.contactUserId ||
      (c.phone && contact.phone && c.phone.replace(/\s+/g, '') === contact.phone.replace(/\s+/g, '')) ||
      (c.email && contact.email && c.email.toLowerCase() === contact.email.toLowerCase())
    )
  );

  if (existingIdx !== -1) {
    data.contacts[existingIdx] = { ...contact, id: data.contacts[existingIdx].id };
    writeLocalData(data);
    return data.contacts[existingIdx];
  }

  data.contacts.unshift(contact);
  writeLocalData(data);
  return contact;
}

export async function dbDeleteContact(contactId: string, userId: string): Promise<boolean> {
  if (isUsingRemoteMongo && mongoDb) {
    const res = await mongoDb.collection<ContactDoc>('contacts').deleteOne({ id: contactId, userId });
    return res.deletedCount > 0;
  }

  const data = readLocalData();
  if (!data.contacts) return false;
  const initialLen = data.contacts.length;
  data.contacts = data.contacts.filter(c => !(c.id === contactId && c.userId === userId));
  if (data.contacts.length !== initialLen) {
    writeLocalData(data);
    return true;
  }
  return false;
}

// ==================== BLOQUEO Y GESTIÓN DE CONTACTOS ====================

export async function dbListBlockedUsers(userId: string): Promise<BlockDoc[]> {
  if (isUsingRemoteMongo && mongoDb) {
    return await mongoDb.collection<BlockDoc>('blockedUsers')
      .find({ userId })
      .sort({ blockedAt: -1 })
      .toArray();
  }

  const data = readLocalData();
  if (!data.blockedUsers) data.blockedUsers = [];
  return data.blockedUsers
    .filter(b => b.userId === userId)
    .sort((a, b) => b.blockedAt - a.blockedAt);
}

export async function dbBlockUser(blockRecord: BlockDoc): Promise<BlockDoc> {
  if (isUsingRemoteMongo && mongoDb) {
    await mongoDb.collection<BlockDoc>('blockedUsers').updateOne(
      { userId: blockRecord.userId, blockedUserId: blockRecord.blockedUserId },
      { $set: blockRecord },
      { upsert: true }
    );
    return blockRecord;
  }

  const data = readLocalData();
  if (!data.blockedUsers) data.blockedUsers = [];
  const existingIdx = data.blockedUsers.findIndex(
    b => b.userId === blockRecord.userId && b.blockedUserId === blockRecord.blockedUserId
  );
  if (existingIdx !== -1) {
    data.blockedUsers[existingIdx] = blockRecord;
  } else {
    data.blockedUsers.unshift(blockRecord);
  }
  writeLocalData(data);
  return blockRecord;
}

export async function dbUnblockUser(userId: string, blockedUserId: string): Promise<boolean> {
  if (isUsingRemoteMongo && mongoDb) {
    const res = await mongoDb.collection<BlockDoc>('blockedUsers').deleteOne({ userId, blockedUserId });
    return res.deletedCount > 0;
  }

  const data = readLocalData();
  if (!data.blockedUsers) return false;
  const initialLen = data.blockedUsers.length;
  data.blockedUsers = data.blockedUsers.filter(
    b => !(b.userId === userId && b.blockedUserId === blockedUserId)
  );
  if (data.blockedUsers.length !== initialLen) {
    writeLocalData(data);
    return true;
  }
  return false;
}

export async function dbIsUserBlocked(userAId: string, userBId: string): Promise<boolean> {
  if (isUsingRemoteMongo && mongoDb) {
    const found = await mongoDb.collection<BlockDoc>('blockedUsers').findOne({
      $or: [
        { userId: userAId, blockedUserId: userBId },
        { userId: userBId, blockedUserId: userAId }
      ]
    });
    return !!found;
  }

  const data = readLocalData();
  if (!data.blockedUsers) return false;
  return data.blockedUsers.some(
    b => (b.userId === userAId && b.blockedUserId === userBId) ||
         (b.userId === userBId && b.blockedUserId === userAId)
  );
}

