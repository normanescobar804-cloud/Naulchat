import { User, Conversation, Message, UserStatusStory, SavedContact, BlockedContact, BubbleColors } from '../types';
import { 
  encryptMessagePayload, 
  decryptMessagePayload, 
  encryptWithAES256, 
  decryptWithAES256 
} from '../utils/security';

const TOKEN_KEY = 'naul_auth_token';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string | null): void {
  if (token) {
    localStorage.setItem(TOKEN_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_KEY);
  }
}

function getAuthHeaders(): Record<string, string> {
  const token = getStoredToken();
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {})
  };
}

// --- AUTHENTICATION ---

export async function apiRegister(payload: {
  name: string;
  phone?: string;
  email?: string;
  password?: string;
  avatar?: string;
  bio?: string;
}): Promise<{ user: User; token: string }> {
  const res = await fetch('/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || 'Error al registrar usuario en la base de datos');
  }
  setStoredToken(data.token);
  return { user: data.user, token: data.token };
}

export async function apiLogin(
  identifier: string,
  password?: string
): Promise<{ user: User; token: string }> {
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier, password })
  });
  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || 'Error al iniciar sesión');
  }
  setStoredToken(data.token);
  return { user: data.user, token: data.token };
}

export async function apiRequestCode(target: string): Promise<{ code: string; message: string }> {
  const res = await fetch('/api/auth/request-code', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ target })
  });
  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || 'Error al solicitar código');
  }
  return { code: data.code, message: data.message };
}

export async function apiVerifyCode(
  target: string,
  code: string,
  name?: string
): Promise<{ user: User; token: string }> {
  const res = await fetch('/api/auth/verify-code', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ target, code, name })
  });
  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || 'Código incorrecto o expirado');
  }
  setStoredToken(data.token);
  return { user: data.user, token: data.token };
}

export async function apiGetMe(): Promise<User | null> {
  const token = getStoredToken();
  if (!token) return null;
  try {
    const res = await fetch('/api/auth/me', {
      headers: getAuthHeaders()
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.user || null;
  } catch (err) {
    console.error('Error in apiGetMe:', err);
    return null;
  }
}

export async function apiGetUsers(): Promise<User[]> {
  try {
    const res = await fetch('/api/users', {
      headers: getAuthHeaders()
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.users || [];
  } catch {
    return [];
  }
}

// --- CONVERSATIONS & CONTACTOS EN BASE DE DATOS ---

export async function apiGetContacts(): Promise<SavedContact[]> {
  try {
    const res = await fetch('/api/contacts', {
      headers: getAuthHeaders()
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.contacts || [];
  } catch {
    return [];
  }
}

export async function apiSaveContact(payload: {
  name: string;
  phone?: string;
  email?: string;
  avatar?: string;
  bio?: string;
}): Promise<{
  contact: SavedContact;
  targetUser: User;
  conversation: Conversation;
} | null> {
  try {
    const res = await fetch('/api/contacts', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Error al guardar contacto');
    }
    return data;
  } catch (err) {
    console.error('Error in apiSaveContact:', err);
    return null;
  }
}

export async function apiDeleteContact(contactId: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/contacts/${contactId}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    const data = await res.json();
    return !!data.success;
  } catch {
    return false;
  }
}

export async function apiGetBlockedContacts(): Promise<BlockedContact[]> {
  try {
    const res = await fetch('/api/contacts/blocked', {
      headers: getAuthHeaders()
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.blockedUsers || [];
  } catch {
    return [];
  }
}

export async function apiBlockContact(payload: {
  blockedUserId: string;
  name?: string;
  phone?: string;
  avatar?: string;
  reason?: string;
}): Promise<BlockedContact | null> {
  try {
    const res = await fetch('/api/contacts/block', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    return data.block || null;
  } catch {
    return null;
  }
}

export async function apiUnblockContact(blockedUserId: string): Promise<boolean> {
  try {
    const res = await fetch('/api/contacts/unblock', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ blockedUserId })
    });
    const data = await res.json();
    return !!data.success;
  } catch {
    return false;
  }
}

export async function apiGetConversations(): Promise<Conversation[]> {
  try {
    const res = await fetch('/api/conversations', {
      headers: getAuthHeaders()
    });
    if (!res.ok) return [];
    const data = await res.json();
    const rawList: Conversation[] = data.conversations || [];

    // Descifrado seguro del último mensaje para vista previa en el cliente
    const decryptedList = await Promise.all(
      rawList.map(async conv => {
        if (conv.lastMessage && conv.lastMessage.content) {
          const participantIds = conv.participantIds || conv.participants?.map(p => p.id);
          const decryptedMsg = await decryptMessagePayload(conv.lastMessage, conv.id, participantIds);
          return {
            ...conv,
            lastMessage: decryptedMsg
          };
        }
        return conv;
      })
    );

    return decryptedList;
  } catch {
    return [];
  }
}

export async function apiCreateConversation(targetUserId: string): Promise<Conversation | null> {
  try {
    const res = await fetch('/api/conversations', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ targetUserId })
    });
    const data = await res.json();
    return data.conversation || null;
  } catch {
    return null;
  }
}

export async function apiDeleteConversation(conversationId: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/conversations/${conversationId}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    const data = await res.json();
    return !!data.success;
  } catch {
    return false;
  }
}

// --- MESSAGES (CLIENT AES-256-GCM E2EE) ---

export async function apiGetMessages(conversationId: string, participantIds?: string[]): Promise<Message[]> {
  try {
    const res = await fetch(`/api/conversations/${conversationId}/messages`, {
      headers: getAuthHeaders()
    });
    if (!res.ok) return [];
    const data = await res.json();
    const rawMessages: Message[] = data.messages || [];

    // Descifrar todos los mensajes recibidos del backend localmente en el cliente con AES-256
    const decryptedMessages = await Promise.all(
      rawMessages.map(msg => decryptMessagePayload(msg, conversationId, participantIds))
    );

    return decryptedMessages;
  } catch (err) {
    console.error('Error al obtener y descifrar mensajes:', err);
    return [];
  }
}

export async function apiSendMessage(
  conversationId: string,
  msgPayload: Partial<Message>,
  participantIds?: string[]
): Promise<Message | null> {
  try {
    // 1. Cifrar en el cliente con AES-256-GCM antes de enviar al backend
    const encryptedPayload = await encryptMessagePayload(
      {
        ...msgPayload,
        content: msgPayload.content || '',
      },
      conversationId,
      participantIds
    );

    // 2. Enviar el payload cifrado por la red al servidor
    const res = await fetch(`/api/conversations/${conversationId}/messages`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(encryptedPayload)
    });
    const data = await res.json();
    if (!data.message) return null;

    // 3. Descifrar el mensaje confirmado para el estado local del cliente
    return await decryptMessagePayload(data.message, conversationId, participantIds);
  } catch (err) {
    console.error('Error al cifrar y enviar mensaje al backend:', err);
    return null;
  }
}

export async function apiEditMessage(
  conversationId: string,
  messageId: string,
  content: string,
  participantIds?: string[]
): Promise<boolean> {
  try {
    // Cifrar el nuevo contenido antes del PUT al backend
    const encRes = await encryptWithAES256(content, conversationId, participantIds);
    const res = await fetch(`/api/conversations/${conversationId}/messages/${messageId}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify({ 
        content: encRes.ciphertext,
        iv: encRes.iv,
        algorithm: 'AES-256-GCM',
        isEncrypted: true
      })
    });
    const data = await res.json();
    return !!data.success;
  } catch {
    return false;
  }
}

export async function apiDeleteMessage(
  conversationId: string,
  messageId: string
): Promise<boolean> {
  try {
    const res = await fetch(`/api/conversations/${conversationId}/messages/${messageId}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    const data = await res.json();
    return !!data.success;
  } catch {
    return false;
  }
}

export async function apiUpdateMessageReactions(
  conversationId: string,
  messageId: string,
  reactions: Record<string, string[]>
): Promise<boolean> {
  try {
    const res = await fetch(`/api/conversations/${conversationId}/messages/${messageId}/reactions`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify({ reactions })
    });
    const data = await res.json();
    return !!data.success;
  } catch {
    return false;
  }
}

export async function apiMarkConversationAsRead(conversationId: string): Promise<string[]> {
  try {
    const res = await fetch(`/api/conversations/${conversationId}/read`, {
      method: 'POST',
      headers: getAuthHeaders()
    });
    const data = await res.json();
    return data.messageIds || [];
  } catch {
    return [];
  }
}

// --- STATUSES / HISTORIAS CON FOTOS, VIDEOS Y MÚSICA ---

export async function apiGetStatuses(): Promise<UserStatusStory[]> {
  try {
    const res = await fetch('/api/statuses', {
      headers: getAuthHeaders()
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.statuses || [];
  } catch {
    return [];
  }
}

export async function apiCreateStatus(payload: {
  mediaUrl?: string;
  mediaType?: 'image' | 'video' | 'text';
  audioTrack?: {
    title: string;
    artist?: string;
    url?: string;
  };
  text?: string;
  bgColor?: string;
}): Promise<UserStatusStory | null> {
  try {
    const res = await fetch('/api/statuses', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    return data.status || null;
  } catch {
    return null;
  }
}

export async function apiRecordStatusView(statusId: string): Promise<{ viewsCount: number; viewers?: any[] } | null> {
  try {
    const res = await fetch(`/api/statuses/${statusId}/view`, {
      method: 'POST',
      headers: getAuthHeaders()
    });
    const data = await res.json();
    return { viewsCount: data.viewsCount || 0, viewers: data.viewers || [] };
  } catch {
    return null;
  }
}

// --- ALMACENAMIENTO SEGURO DE ARCHIVOS CON VALIDACIÓN EN BACK-END ---

export async function apiUploadFile(
  dataUrl: string,
  fileName?: string,
  mimeType?: string,
  isPrivate: boolean = true
): Promise<{
  success: boolean;
  fileId: string;
  url: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
}> {
  const res = await fetch('/api/upload', {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify({ dataUrl, fileName, mimeType, isPrivate })
  });

  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || 'Error al validar y subir el archivo al servidor');
  }

  return data;
}

// --- CONTROL DE SESIONES Y SEGURIDAD ---

export async function apiListSessions(): Promise<import('../types').UserSession[]> {
  try {
    const res = await fetch('/api/auth/sessions', {
      headers: getAuthHeaders()
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.sessions || [];
  } catch {
    return [];
  }
}

export async function apiRevokeSession(sessionId: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/auth/sessions/${sessionId}/revoke`, {
      method: 'POST',
      headers: getAuthHeaders()
    });
    const data = await res.json();
    return !!data.success;
  } catch {
    return false;
  }
}

export async function apiRevokeOtherSessions(): Promise<number> {
  try {
    const res = await fetch('/api/auth/sessions/revoke-others', {
      method: 'POST',
      headers: getAuthHeaders()
    });
    const data = await res.json();
    return data.revokedCount || 0;
  } catch {
    return 0;
  }
}

export async function apiGetSecurityStatus(): Promise<import('../types').SecurityReport | null> {
  try {
    const res = await fetch('/api/security/status', {
      headers: getAuthHeaders()
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.security || null;
  } catch {
    return null;
  }
}

export async function apiUpdateBubbleColors(bubbleColors: BubbleColors): Promise<User | null> {
  try {
    const res = await fetch('/api/users/profile', {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify({ bubbleColors })
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.user || null;
  } catch {
    return null;
  }
}

